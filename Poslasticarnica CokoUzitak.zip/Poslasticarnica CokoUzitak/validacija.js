const forma = document.getElementById('form');
const korisnickoIme = document.getElementById('korisnickoime');
const email = document.getElementById('email');
const lozinka = document.getElementById('lozinka');
const potvrdalozinke = document.getElementById('potvrdalozinke');
const porukaa = document.getElementById('poruka');


forma.addEventListener('submit', e => {
  e.preventDefault();

  proveriUnose();
});

function proveriUnose() {
  // Ukloni beline sa početka i kraja unosa
  const vrednostKorisnickogImena = korisnickoIme.value.trim();
  const vrednostEmaila = email.value.trim();
  const vrednostLozinke = lozinka.value.trim();
  const vrednostLozinke2 = potvrdalozinke.value.trim();
  const porukaa = poruka.value.trim();

  if (vrednostKorisnickogImena === '') {
    postaviGreskuZa(korisnickoime, 'Polje ne može biti prazno!');
  } else {
    postaviUspesnoZa(korisnickoime);
  }

 if (porukaa=== '') {
    postaviGreskuZa(poruka, 'Polje ne može biti prazno!');
  } else {
    postaviUspesnoZa(poruka);
  }

  if (vrednostEmaila === '') {
    postaviGreskuZa(email, 'Polje ne može biti prazno!');
  } else {
    postaviUspesnoZa(email);
  }

  if (vrednostLozinke === '' || vrednostLozinke.length<8) {
    postaviGreskuZa(lozinka, 'Polje ne može biti prazno!');
  } else {
    postaviUspesnoZa(lozinka);
  }

  if (vrednostLozinke2 === '') {
    postaviGreskuZa(potvrdalozinke, 'Polje ne može biti prazno!');
  } else if (vrednostLozinke !== vrednostLozinke2) {
    postaviGreskuZa(potvrdalozinke, 'Lozinke se ne podudaraju');
  } else {
    postaviUspesnoZa(potvrdalozinke);
  }
}

function postaviGreskuZa(input, poruka) {
  const poljaforme = input.parentElement;
  const malaPoruka = poljaforme.querySelector('small');
  poljaforme.className = 'poljaforme greska'; // Ispravljena klasa
  malaPoruka.innerText = poruka;
}


function postaviUspesnoZa(input) {
  const poljaforme = input.parentElement;
  poljaforme.className = 'poljaforme uspesno';
}

function isEmail(email) {
  return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}
