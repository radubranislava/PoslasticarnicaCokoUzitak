const kontejnerproizvoda = [...document.querySelectorAll('.kontejnerzaproizvode')];
const sledeci = [...document.querySelectorAll('.sledeci')];
const prethodni = [...document.querySelectorAll('.prethodni')];

kontejnerproizvoda.forEach((proizvod, i) => {
    let dimenzijekontejnera= proizvod.getBoundingClientRect();
    let sirinakontejnera = dimenzijekontejnera.width;

    sledeci[i].addEventListener('click', () => {
        proizvod.scrollLeft += sirinakontejnera;
    })

    prethodni[i].addEventListener('click', () => {
        proizvod.scrollLeft -= sirinakontejnera;
    })
})
