let korpa = [];
let ukupnaCena = 0;

function dodajUKorpu(button) {
    let nazivProizvoda = button.getAttribute('data-name');
    let cenaProizvoda = parseFloat(button.getAttribute('data-price'));
    
    let kolicinainput = button.previousElementSibling;
    let kolicina = parseInt(kolicinainput.value);

    if (kolicina > 0) {
        korpa.push({ naziv: nazivProizvoda, cena: cenaProizvoda, kolicina: kolicina });
        ukupnaCena += cenaProizvoda * kolicina;
        osveziKorpu();
    }
}

function osveziKorpu() {
    let korpakontejner = document.querySelector('.proizvodiukorpi');
    let krajnje = document.querySelector('.ukupno');

    korpakontejner.innerHTML = '';
    
    korpa.forEach(item => {
        let proizvodukorpi = document.createElement('div');
        proizvodukorpi.classList.add('cart-item');
        proizvodukorpi.innerHTML = `
            <p>${item.naziv} - ${(item.cena * item.kolicina).toFixed(2)}</p>
        `;
        korpakontejner.appendChild(proizvodukorpi);
    });

    krajnje.textContent = `Ukupna cena: ${ukupnaCena.toFixed(2)}`;
}





function ispisInformacijeOTorti() {
  const unos = document.getElementById("unostorte").value;
  const kontejnerzainformacije = document.getElementById("informacijetorte");

  if (unos.length === 0) {
    kontejnerzainformacije.innerHTML = "Unesite ime torte da biste videli informacije.";
    return;
  }

  // Koristite XMLHttpRequest da biste dobili podatke o torti sa servera.
  const xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
      const podaci = JSON.parse(this.responseText);

      if (podaci.ime) {
        // Prikaz informacija o torti
        kontejnerzainformacije.innerHTML = `
          <h3>${podaci.ime}</h3>
          
          <p>Cena: ${podaci.cena}</p>
          <p>Opis: ${podaci.opis}</p>
		  <p>Broj spratova: ${podaci.brojspratova}</p>
        `;
      } else {
        kontejnerzainformacije.innerHTML = "Torta sa tim imenom nije pronađena.";
      }
    }
  };

  xhttp.open("GET", "torte.php?ime=" + unos, true);
  xhttp.send();
}

