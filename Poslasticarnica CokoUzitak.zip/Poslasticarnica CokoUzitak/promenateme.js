
function postaviTemu(tema) {
    const kolacici = document.getElementById('kolacici');
    kolacici.classList.remove('tamnatema', 'svetlatema');
    kolacici.classList.add(tema);

   
    document.cookie = `tema=${tema}; expires=Fri, 31 Dec 9999 23:59:59 GMT`;
}



function promeniTemu() {
    const kolacici = document.getElementById('kolacici');
    const trenutnaTema = kolacici.classList.contains('tamnatema') ? 'svetlatema' : 'tamnatema';

   
    postaviTemu(trenutnaTema);
}


function proveraKolacica() {
    const kolacicTema = document.cookie.split('; ').find(row => row.startsWith('tema='));
    if (kolacicTema) {
        const tema = kolacicTema.split('=')[1];
        postaviTemu(tema);
    } else {
        
        postaviTemu('tamnatema');
    }
}


const promenidugme = document.getElementById('promeni-temuu');
promenidugme.addEventListener('click', promeniTemu);


window.addEventListener('load', proveraKolacica);



