<?php
$torte = array(
    "torta1" => array(
        "ime" => "Torta 1",
        "cena" => "7000 dinara",

        "brojspratova" => "3",
        "opis" => "Ovo je ukusna torta  sa cokoladom i jagodama."
    ),
        "torta1" => array(
        "ime" => "Torta 2",
        "cena" => "7800 dinara",

        "brojspratova" => "2",
        "opis" => "Ovo je ukusna torta   sa cokoladom i jagodama."
    ),
    "torta3" => array(
        "ime" => "Torta 3",
        "cena" => "8700",
        "brojspratova" => "4",
        "opis" => "Torta broj 3 sa cokoladnim prelivom i bademima."
    )
);

// Proverite da li je prosle?en "ime" parametar (ime torte)
if (isset($_GET['ime']) && array_key_exists($_GET['ime'], $torte)) {
    $selectedTorta = $_GET['ime'];
    // Vra?amo informacije o odabranoj torti u JSON formatu
    header('Content-Type: application/json');
    echo json_encode($torte[$selectedTorta]);
} else {
    // Ako nije prosle?en validan "ime" parametar, vra?amo prazan JSON objekat
    header('Content-Type: application/json');
    echo json_encode(array());
}
?>
